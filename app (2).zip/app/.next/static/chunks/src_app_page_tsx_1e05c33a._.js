(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_6e3b8e47._.js",
  "static/chunks/node_modules_68a2b6e6._.js"
],
    source: "dynamic"
});

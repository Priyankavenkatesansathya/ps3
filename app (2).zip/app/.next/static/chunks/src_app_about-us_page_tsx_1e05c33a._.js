(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_8127a870._.js",
  "static/chunks/node_modules_b032a7d8._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_7f6c4d5e._.js",
  "static/chunks/node_modules_a282a972._.js"
],
    source: "dynamic"
});

import { JobSearchPageContent } from '@/components/job-search-page-content';
import { jobs as initialJobs } from '@/lib/data';
import { Header } from '@/components/header';
import type { Job } from '@/lib/types';


export default function Home() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex-1">
        <JobSearchPageContent initialJobs={initialJobs} />
      </main>
    </div>
  );
}
